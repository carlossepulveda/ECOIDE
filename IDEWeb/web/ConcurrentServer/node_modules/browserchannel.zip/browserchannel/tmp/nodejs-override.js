var Image, XMLHttpRequest, request, url, window;
var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };
goog.provide('bc.node');
request = require('request');
Image = function() {
  this.__defineSetter__('src', __bind(function(url) {
    url = url.toString();
    if (url.match(/^\/\//)) {
      url = 'http:' + url;
    }
    return request(url, __bind(function(error, response, body) {
      if (error != null) {
        return typeof this.onerror === "function" ? this.onerror() : void 0;
      } else {
        return typeof this.onload === "function" ? this.onload() : void 0;
      }
    }, this));
  }, this));
  return this;
};
XMLHttpRequest = require('../XMLHttpRequest').XMLHttpRequest;
goog.require('goog.net.XmlHttpFactory');
goog.net.BrowserChannel.prototype.createXhrIo = function(hostPrefix) {
  var xhrio;
  xhrio = new goog.net.XhrIo();
  xhrio.createXhr = function() {
    return new XMLHttpRequest();
  };
  return xhrio;
};
window = {
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  setInterval: setInterval,
  clearInterval: clearInterval
};
window.location = null;
window.navigator = {
  userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.202 Safari/535.1"
};
/*
  setTimeout: (f, t) ->
    console.log 'setTimeout'
    setTimeout (-> console.log(f.toString()); f()), t
  clearTimeout: clearTimeout
  setInterval: (f, t) ->
    console.log 'setTimeout'
    setInterval (-> console.log 'tick'; f()), t
  clearInterval: clearInterval
*/
goog.global = window;
url = require('url');
exports['setDefaultLocation'] = function(loc) {
  if (typeof loc === 'string') {
    loc = url.parse(loc);
  }
  return window.location = loc;
};