Most of the files in here are built by the closure compiler.

They are assembled by running

    % cake client
