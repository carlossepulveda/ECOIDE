This directory contains the unit tests for sharejs. They are written with nodeunit.

Run them all with:

    % cake test

from the root directory of the repository.

Run just one test with:

    % nodeunit testFoo.coffee
