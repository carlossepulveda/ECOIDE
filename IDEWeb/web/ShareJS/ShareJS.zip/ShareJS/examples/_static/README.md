This is a simple static renderer which uses mustache to render out an HTML page
from the document named on the URL path.

Access this demo by browsing to:
/static/DOCNAME
from your server.

(Eg, try /static/html)
