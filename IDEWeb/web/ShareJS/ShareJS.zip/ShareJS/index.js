require('coffee-script');
module.exports = require('./src');
